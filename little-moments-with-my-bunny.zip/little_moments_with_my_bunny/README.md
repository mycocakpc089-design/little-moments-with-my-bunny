# Little Moments With My Bunny

A free, mobile-friendly romantic memory page with a moonlit river atmosphere, gentle star animations, a photobooth photo, and hidden notes. No music and no external libraries.

## Preview locally
Open `index.html` in a browser. Keep the `assets` folder beside it so the photo loads.

## Publish as a separate GitHub Pages site
1. Create a **new** GitHub repository, for example `little-moments-with-my-bunny`. Do not edit the existing `last-love-letter` repository.
2. Upload `index.html`, `README.md`, and the `assets` folder (including `our-photobooth.jpg`) to the root of the new repository.
3. In the new repository, open **Settings → Pages**.
4. Under Build and deployment, choose **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**, then Save.
6. Wait a minute or two for GitHub Pages to publish. The address is usually `https://YOUR-USERNAME.github.io/REPOSITORY-NAME/`.

## Customize
Edit text in `index.html` to change captions or messages. The photo is `assets/our-photobooth.jpg`.
